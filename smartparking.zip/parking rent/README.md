
1. Register new users.
2. Log in registered users.
3. Logged in users can book for a parking spot from different parking zones, get parking receipt with parking details and checkout from a parking spot.
4. Admins can create parking zones indicating the number of parking spots available.
5. Admin can view parking details of all users.


 pip install -r requirements.txt
```

Then follow these steps:
1. Move to root folder 

cd parking_management
```
2. Create a `.env` file in the root folder, provide the required database information  to the `.env` file (.env.example file is provided to help set this information). You can choose to rename the .env.example to .env

3. Create the tables with the django command line

```bash
python3 manage.py makemigrations
```
then migrate the changes
 
```bash
python3 manage.py migrate
```


```bash
python3 manage.py createsuperuser
```




```bash
python manage.py runserver
```


